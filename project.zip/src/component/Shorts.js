import React from 'react'
import '../App.css'
import Logo from '../images/logo.png'
export default function Shorts() {
  return (
   <>
   
    <div className='col-md-10' style={{height:'900px',background:'yellow',color:'purple'}}>
        <center><h1>Shorts</h1></center>
      
    </div>

   </>
  )
}