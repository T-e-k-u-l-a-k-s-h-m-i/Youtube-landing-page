import React, { useState,useEffect } from 'react'
import axios from 'axios'

export default function Dataapi() {

    const[products, setProducts]=useState([{}])
    // const [images,seImages]=useState(Array)

   useEffect(()=>{
      axios.get('https://dummyjson.com/products')
      .then(res => setProducts(res.data.products))                               
   },[])

   console.log(products)
   
    
  
}

