import React from 'react'
import pagelogo from '../images/404.jpeg' 
export default function Errorpage() {
  return (
  <>
 <div className='col-md-10' style={{background:'grey'}}>
       <div class="row">
    <center><h1><u>Errorpage</u></h1></center>

    <center><img src={pagelogo} style={{height:'400px', width:'400px'}}></img></center>
    </div>
    </div>
    </>
    
  )
}