import React from 'react'

export default function Music() {
  return (
    <>
    <div className='col-md-10' style={{height:'900px',background:'pink'}}>
    <center><div class="form-group" >
          <input type="text" class="font-control" placeholder="search" id="search" style={{width:'500px'}}></input><i class="fa fa-microphone" aria-hidden="true"></i><i class="fa fa-ellipsis-v" aria-hidden="true" id="sub"></i>   <i class="fa fa-bell-o" aria-hidden="true" id="sub"></i>
          
          </div></center>
        <div class="classname button">
        <button type="button" class="btn btn-secondary">All</button>
        <button type="button" class="btn btn-secondary">Music</button>
        <button type="button" class="btn btn-secondary">Filmi</button>
        <button type="button" class="btn btn-secondary">Cricket</button>
        <button type="button" class="btn btn-secondary">Game shows</button>
        <button type="button" class="btn btn-secondary">Live</button>
        <button type="button" class="btn btn-secondary">Awards</button>
        <button type="button" class="btn btn-secondary">Computer programming</button>
        <button type="button" class="btn btn-secondary">Posts</button>
        <button type="button" class="btn btn-secondary">Lectures</button>
        <button type="button" class="btn btn-secondary">Watched</button>
        
        </div>
    <div class="row">
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/jJvDnYdD8JQ?si=U-ls0LDwVkwM-_9C" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/hHB1Ikzfpmc?si=EO900VaE0tMqRxz1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/gmMDGsSXbec?si=jJPScKT4ka5UzyUD" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  </div>
  <div class="row">
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/166tsC3RUcc?si=EqBDhcJ0uzOzbagV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/XcXku4Q3Gn4?si=y4lfJrGilfp4n_Zh" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/mY9fNwGE7YA?si=b7yskIJfzOjQ4tr2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  
  </div>
  <div class="row">
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/IV_JCpPe3SM?si=H3Tk4aEn2zyI_V_V" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/Vds8ddYXYZY?si=URFefNVZ_sm3M67D" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  <div class="col-md-4"><iframe width="350" height="200" src="https://www.youtube.com/embed/khOFw2f4bQY?si=VXnzbhig8xLXRd1X" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
  </div>
  <div class="button class">
  <button type="Music"></button>
  </div>
</div>
    </>
  )
}
