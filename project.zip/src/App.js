import React from 'react'
import logo from './logo.svg';
import './App.css';
import Sidebar from './component/Sidebar';
import Content from './component/Content';
import Shorts from './component/Shorts';
import Errorpage from'./component/Errorpage';
import Music from'./component/Youtube';
import A from './component/A';
import Hooks from './component/Hooks';
import Hooks2 from './component/Hooks2';
import Dataapi from './component/Dataapi';

import { BrowserRouter,Routes,Route,Link } from 'react-router-dom';

 function App() {
  const details=[
    {
    name: "Tester",
    roll: 1234,
    group:"MCA"
  },
  {
    name:"Aditya",
    roll:68709,
    group:"MBA"
  },
  {
    name:"rjymca",
    roll:6785,
    group:"MSC"
  }
  ];
  return (
   <>
   
   
     <div className='Container-fluid'>
       <div className='row'>
       
       <BrowserRouter>
       <Sidebar></Sidebar>
       <Routes>
       <Route path="/dataapi" element={<Dataapi/>}></Route>
       <Route path="/hooks2" element={<Hooks2/>}></Route>
       <Route path="/hooks" element={<Hooks/>}></Route>
        <Route path="/youtube music" element={<Music/>}></Route>

        <Route path="/youtube music mini" element={<Music/>}></Route>
        <Route path="*" element={<Errorpage/>}></Route>
        
         
        <Route path="/" element={<Content/>}></Route>
          <Route path="/home" element={<Content/>}></Route>
          
          <Route path="/shorts" element={<Shorts/>}></Route>
          <Route path="/music" element={<Music/>}></Route>
          <Route path="/A" element={<A data={details}/>}></Route>
         
         
                
  </Routes>
  
   </BrowserRouter>
   
   
       </div>
     </div>
    
     
   </>


  );
}

export default App;